// 액션 타입 정의
export const CHANGE_COLOR = 'counter/CHANGE_COLOR';
export const INCREMENT = 'counter/INCREMENT';
export const DECREMENT = 'counter/DECREMENT';

export default {
  CHANGE_COLOR,
  INCREMENT,
  DECREMENT,
};
