import React from 'react';
import './Header.scss';

const items = [];

const LetterButton = ({ context, onClick }) => {
  return <span />;
};

const Header = () => {
  return <div className="Header"></div>;
};

export default Header;
