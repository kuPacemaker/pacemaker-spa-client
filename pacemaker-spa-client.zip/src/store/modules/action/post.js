import axios from 'axios';
// import { createAction } from 'redux-actions';
import { pending, success, failure } from '../creators/post';
// import { GET_POST } from '../type/post';

const getPostAPI = (postId) =>
  axios.get(`https://jsonplaceholder.typicode.com/posts/${postId}`);

export const getPost = (postId) => (dispatch) => {
  dispatch(pending());
  return getPostAPI(postId)
    .then((response) => {
      dispatch(success(response));
    })
    .catch((error) => {
      dispatch(failure(error));
    });
};
// export const getPost = createAction(GET_POST, getPostAPI);
export const simpleUpdate = (
  url,
  params = {},
  isPlain = false,
  notToConvert = false
) => {
  return (dispatch) => {
    let result;
    dispatch(creator.postStart());
    return APICaller.post(url, params, {}, isPlain, notToConvert)
      .then(({ data }) => {
        result = data;
        return dispatch(creator.postEnd());
      })
      .then(() => result);
  };
};
