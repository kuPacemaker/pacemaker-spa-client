export const GET_POST_PENDING = 'post/GET_POST_PENDING';
export const GET_POST_SUCCESS = 'post/GET_POST_SUCCESS';
export const GET_POST_FAILURE = 'post/GET_POST_FAILURE';
export const GET_POST = 'post/GET_POST';
// export default {
//   GET_POST_PENDING,
//   GET_POST_SUCCESS,
//   GET_POST_FAILURE,
// };
